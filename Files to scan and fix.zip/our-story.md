---
title: "Our Story"
layout: "our-story.njk"
permalink: "our-story/index.html"
content: >
  Welcome to Beyond the Back Door.  
  We believe in transforming outdoor spaces into something personal and magical.
---
