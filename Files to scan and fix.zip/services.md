---
title: "Services"
layout: "services.njk"
permalink: "services/index.html"
content: >
  We offer bespoke garden design services, including consultations, planting plans, and full redesigns.
---
