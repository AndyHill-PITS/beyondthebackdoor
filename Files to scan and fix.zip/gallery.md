---
title: "Gallery"
layout: "gallery.njk"
permalink: "gallery/index.html"
groups:
  - group_title: "Front Garden Makeovers"
    images:
      - image: "/images/uploads/example1.jpg"
        caption: "Before and after transformation."
      - image: "/images/uploads/example2.jpg"
        caption: "New seating area with wildlife planting."
  - group_title: "Back Garden Retreats"
    images:
      - image: "/images/uploads/example3.jpg"
        caption: "Pergola and relaxed seating design."
---
